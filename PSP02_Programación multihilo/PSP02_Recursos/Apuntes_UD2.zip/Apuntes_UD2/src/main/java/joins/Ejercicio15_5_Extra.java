/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joins;

import static java.lang.System.out;
import java.util.Random;

/**
 *
 * @author Juan Morillo Fernandez
 */
/*
Un hilo espere a otro


*/
class A implements Runnable {
    
    Thread other; // el hilo a esperar
    public A(){} // constructor sin parametros ( new A() )
    public A( Thread t ) {   // constructor que recibe otro thread
        this.other = t;
    }
    
    public void run() {

        Random random = new Random(); //sacar numeros aleatorios de aqui
        int r = 0;
        int t = 10;

        while( (r = random.nextInt(100)) != 2 ) {  // mientras no sea 2

            out.println( this + " " + r ); // imprimelo

            // si ya corrio 10 veces y su "otro" hilo esta vivo 
            if( other != null && t-- < 0 && other.isAlive() ) 
                try  {  
                out.println( this + " esperando ");// lo espera
                other.join();
            } catch( InterruptedException ie ) {}
        }
        out.println( this + " fin");
    }
    
    public String toString() {
        return Thread.currentThread().getName();
    }
   
    
    public static void main( String ... args ) throws InterruptedException { 
        
        
        Thread uno = new Thread( new A() );
        //comunicación entre hilos pasando las referencias
        Thread dos = new Thread( new A(uno) );
        dos.start();
        uno.start();
        out.println( "fin del codigo" );
    }
}