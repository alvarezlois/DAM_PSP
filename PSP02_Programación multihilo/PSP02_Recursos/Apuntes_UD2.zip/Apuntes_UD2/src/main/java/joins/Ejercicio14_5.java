/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package joins;

/**
 *
 * @author Juan Morillo Fernandez
 */

//Que el main espere por los demás hilos

class Multiples extends Thread{
	
	//constructor
	public Multiples (String nombre){
		super(nombre);
	}
	
	//redefiniciÛn del mÈtodo run(), que es el que contiene
	//las indicaciones de lo que har· el hilo
	public void run(){
		try{
			for (int i=0;i<4;i++){
				//Mostrar· el nombre del hilo actual
				System.out.println((Thread.currentThread()).getName()+" esta ejecutandose.....");
				//Duermo el hilo actual un segundo
				Thread.sleep(1000);
		
			}	
		}catch (InterruptedException ex){}
		System.out.println((Thread.currentThread()).getName()+" ha finalizado.");
	}
}



public class Ejercicio14_5 {
    
   	public static void main(String args[]){
 
                Multiples hilo1 = new Multiples("Primero");
		Multiples hilo2 = new Multiples("Segundo");
		Multiples hilo3 = new Multiples("Tercero");
		Multiples hilo4 = new Multiples("Cuarto");
	
		try{
		
			hilo1.start();
			hilo1.join();
			
			hilo2.start();
			hilo2.join();
			
			hilo3.start();
			hilo3.join();
			
			hilo4.start();
			hilo4.join();
			
		//El Join también genera posible excepcion
		}catch (InterruptedException ex){}
		
		System.out.println("Fin de la aplicación principal");	
	
        } 
}
