/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sincronizacion;

public class MainSincronizada{
	public static void main(String args[]){
		Listado lista= new Listado();
		
		//Creo los objetos hilo
		Thread primero = new Ej2NoSincro(lista);
		Thread segundo = new Ej2NoSincro(lista);
		
		//Los lanzo
		primero.start();
		segundo.start();
		
		try{
			Thread.sleep(4000);
		}
		catch(InterruptedException ex){
			System.out.println("Interrupción");
		}
		System.out.println("\nYa termine.");		
	}
}

class Ej2NoSincro extends Thread{
	Listado salida;
	
	//Constructor
	Ej2NoSincro(Listado sali){
		salida=sali;
	}
	
	public void run(){
		salida.Mostrar();
	}
}

class Listado{
    
        //Ojoo se permite antes o despues del modificador de acceso
	synchronized public void Mostrar(){
		System.out.println("\nEsta es mi salida");
		for (int i=0; i<8; i++){
			System.out.print(i+" ");
		}
	}
}
