/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sincronizacion;

class ObjetoComun {
	
    //luego probar con synchronized 
    public void Mostrar (String mensaje) {
		System.out.println("En marcha...! " + mensaje);
		try {
			Thread.sleep(2000);
			} catch (InterruptedException ex) {
			System.out.printf("Interrupcion");
		}
		System.out.println("Ha llegado...! " + mensaje);
	}
}

class Sincronizada extends Thread {
	ObjetoComun comparti;
	String nom;
	//Constructor
	Sincronizada (String nombre, ObjetoComun compartido) {
		comparti=compartido;
		nom=nombre;
	}
	public void run() {
		comparti.Mostrar(nom);
	}
}


public class MainNoSincronizada {
	public static void main(String args[]) {
		ObjetoComun compartido = new ObjetoComun();
		
		//Creo los 4 hilos que usar·n el objeto compartido anterior
		Sincronizada dibujo1 = new Sincronizada("Caperucita", compartido);
		Sincronizada dibujo2 = new Sincronizada("Blancanieves", compartido);
		Sincronizada dibujo3 = new Sincronizada("Pinocho", compartido);
		Sincronizada dibujo4 = new Sincronizada("Pulgarcito", compartido);
		
		//Lanzo los hilos
		dibujo1.start();
		dibujo2.start();
		dibujo3.start();
		dibujo4.start();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException ex) {
				System.out.printf("Interrupcion");
		}
		System.out.println("Hemos terminado amiguitos");
	}
}

