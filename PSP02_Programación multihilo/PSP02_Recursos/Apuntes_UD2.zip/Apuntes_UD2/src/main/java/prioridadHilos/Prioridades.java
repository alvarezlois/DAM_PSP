/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prioridadHilos;

/**
 *
 * @author Juan Morillo Fernandez
 */
/*
Enunciado: Programa tres hilos, que llamaremos tortuga, liebre y guepardo. Estos
tres hiloa tienen distintas prioridades e imprimen su nombre treinta veces
en la salida estandard y se bloquean para dar paso a otros hilos.
El hilo de nombre tortuga debe tener menos prioridad que el hilo liebre, y este
menos que guepardo

*/

class Animal extends Thread{

    String nombre;
    public Animal(int prioridad, String nombre){
    
        this.nombre= nombre;
        setPriority(prioridad);
    }
    
    public void run(){
        for (int i=0;i<30; i++)
        {
            System.out.println(nombre);
            this.yield();
        }
        System.out.println("\n LLega "+ nombre);
    }
}


public class Prioridades {
    
   
    // Las prioridades de los hilos en procesadores multinucleo NO ES EFICAZ,
    //incluso la JVM entre prioridades parecidas las trata iguales
    //Para un control mas "profesional" y mayor control se usa Executor
    // framework que si nos da tiempo veremos algo
    public static void main(String argv[])
    {
       Animal tortuga = new Animal(1,"T");
       Animal liebre = new Animal(5,"L");
       Animal guepardo = new Animal(10,"G");

       tortuga.start();
       liebre.start();
       guepardo.start();

    System.out.println("Procesadores:"+ Runtime.getRuntime().availableProcessors());
    }
}
