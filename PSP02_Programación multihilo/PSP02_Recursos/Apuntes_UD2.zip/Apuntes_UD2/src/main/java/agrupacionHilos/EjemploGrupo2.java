/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agrupacionHilos;

class HiloGrupo2 implements Runnable
{

  // Método run
    public void run()
    {
		 System.out.println(Thread.currentThread().getName() +
            "comienza a ejecutarse");
			try{
				Thread.currentThread().sleep(1000);
			}catch(InterruptedException e){System.out.println("Excpeción al dormir");}
         System.out.println(Thread.currentThread().getName() +
            " ha terminado de ejecutarse");
    }
}




public class EjemploGrupo2{

	public static void main(String[] args)
    {
       	
       try
        {
            // Creaun nuevo ThreadGroup y un hijo de ese
            //nuevo ThreadGroup.
            ThreadGroup parentGroup =
                new ThreadGroup("ThreadGroup padre");
	
            ThreadGroup childGroup =
                new ThreadGroup(parentGroup, "ThreadGroup Hijo");

            // Crea un thread y lo lanza
			HiloGrupo2 run1=new HiloGrupo2();//Crea un objeto HiloGrupo2 (Runnable)
            Thread hilo1 = new Thread(parentGroup, run1);
            System.out.println("Comenzando " +
                hilo1.getName() + "...");
            hilo1.start();
            
            // Crea un segundo thread y lo lanza
			HiloGrupo2 run2=new HiloGrupo2();//Crea un objeto HiloGrupo2 (Runnable)
            Thread hilo2 = new Thread(childGroup, run2);
            System.out.println("Comenzando " +
                hilo2.getName() + "...");
            hilo2.start();
            
            // Muestra el número de hilos activos en el
            // nuevo ThreadGroup.
            System.out.println("Threads activos en el grupo \"" +
                parentGroup.getName() + "\" = " +
                parentGroup.activeCount());

            // Espera hasta que los otros hilos acaben
            hilo1.join();
            hilo2.join();
            
           //Conclusión los grupos de hilos tb son hilos
        }
        catch (InterruptedException ex)
        {
            System.out.println(ex.toString());
        }
    }
  

  
}