/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sincronizacionVar;

/**
 *
 * @author Juan Morillo Fernandez
 */
public class ContadorHilo extends Thread {

    Contador cont;
    
    public ContadorHilo(String p_nombre, Contador cont) {
    
        super(p_nombre);
        this.cont= cont;
    }

    public void run() {

        for(int i=0;i<3;i++){
        
            try{
                synchronized(cont)
                {
                    int a = cont.getContador();
                    sleep((long)Math.random()*10);
                    cont.setContador(a+1);
                    System.out.println(getName() + " - contador - " + cont.getContador());
                    sleep((long)Math.random()*10);

                }
            }
                catch(InterruptedException e){
                        System.out.println("Interrupcion del hilo");
                        }
            
            }
        System.out.println("Fin..."+ getName());
        
     }
}
    
    

