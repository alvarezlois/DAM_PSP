/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sincronizacionVar;

/**
 *
 * @author Juan Morillo Fernandez
 */
class Contador {
    
    int contador=0;
    public int getContador(){
    
        return this.contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }
    
    
}
