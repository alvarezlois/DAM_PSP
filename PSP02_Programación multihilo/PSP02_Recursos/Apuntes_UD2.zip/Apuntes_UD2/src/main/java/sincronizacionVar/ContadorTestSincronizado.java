/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sincronizacionVar;

/**
 *
 * @author Juan Morillo Fernandez
 */
/*
Enunciado crea cuatro hilos que accedan a una variable compartida que es un 
contador y aumenta en una unidad su valor.

*/


public class ContadorTestSincronizado {
    
    
    public static void main(String[] args){
    
        //Recurso que se va a compartir
        Contador cont = new Contador();
        
        ContadorHilo hilo1= new ContadorHilo("Hilo1",cont);
        ContadorHilo hilo2= new ContadorHilo("Hilo2",cont);
        ContadorHilo hilo3= new ContadorHilo("Hilo3",cont);
        ContadorHilo hilo4= new ContadorHilo("Hilo4",cont);

        
        hilo1.start();
        hilo2.start();
        hilo3.start();
        hilo4.start();

        try{
            hilo1.join();
            hilo2.join();
            hilo3.join();
            hilo4.join();

        
        } catch (InterruptedException e){
          System.out.println("Interrupcion del hilo");

        }
        System.out.println("Terminamos el programa");

    }
}
