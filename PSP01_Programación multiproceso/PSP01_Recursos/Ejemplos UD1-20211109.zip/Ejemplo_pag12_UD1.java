/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package psp_1ºunidad;

import java.io.IOException;
import java.util.Arrays;

/**
 *
 * @author jmor
 */
public class Ejemplo_pag12_UD1 {
   
    public static void main(String[] args) {
        if (args.length <= 0){
            System.out.println("Se necesita un programa a ejecutar");
            System.exit(-1);
        }
        Runtime runtime = Runtime.getRuntime();
        try{
        
            Process process = runtime.exec(args);
            process.destroy();
            
            int retorno = process.waitFor();
            System.out.println("La ejecucion de " + Arrays.toString(args) + " devuelve " + retorno);
        
        
        } catch(IOException ex){
            
            System.err.println("Excepcion de E/S!");
            System.exit(-1);
        
        } catch (InterruptedException ex){
             System.err.println("Excepcion interrupción");
             System.exit(-1);
        }
        
    }
}
