/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package psp_1ºunidad;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 *
 * @author jmor
 */
public class Ejemplo_pag6_UD1_version_Windows {
    
    public static void main(String[] args) throws IOException {
        
        int exitVal;
        
        Runtime r = Runtime.getRuntime();
        String comando = "CMD /C DIR";
        Process p = null;
        
        p= r.exec(comando);
        InputStream is = p.getInputStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        
        String linea;
        while ((linea =br.readLine())!= null) System.out.println(linea);
        
        br.close();
        
        try{
            exitVal= p.waitFor();
            System.out.println("Valor de salida: "+ exitVal);
        }catch (InterruptedException e){ e.printStackTrace();}
            
        
    }
}
