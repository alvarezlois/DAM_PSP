/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package psp_1ºunidad;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jmor
 */
public class Ejemplo_pag3_UD1 {
   
    public static void main(String[] args) throws IOException, InterruptedException {
        
         Runtime rt = Runtime.getRuntime();           
         Process p=null;            
        
            p = rt.exec("calc");
            //p = rt.exec("notepad");
            p.waitFor();
       
    }
}
