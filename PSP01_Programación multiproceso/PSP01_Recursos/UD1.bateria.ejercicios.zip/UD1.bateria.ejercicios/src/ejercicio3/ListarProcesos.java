package ejercicio3;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.Process;
import java.lang.Runtime;


public class ListarProcesos {

	public static void main(String[] args) {
		Process proceso; // Instanciamos un objeto proceso
	try {
		
		String osType = System.getProperty("os.name"); // Obtenemos el nombre del SO que estamos utilizando
		
		// Si es Windows lanzar tasklist, y si no (si es Linux) lanzar ps.
		if (osType.toUpperCase().contains("WIN")) {
			proceso = Runtime.getRuntime().exec("tasklist /FI \"STATUS eq running\"");
		} else {
			proceso = Runtime.getRuntime().exec("ps -a");
		}
		
		
		// Creamos el flujo de lectura y lo unimos a la salida del proceso
		InputStreamReader isr = new InputStreamReader(proceso.getInputStream());
		BufferedReader br = new BufferedReader(isr); 
		
		String line; // Variable con contendr� la l�nea leida del flujo
		
		// Mientras que haya datos en el flujo mostrarlos linea por linea por pantalla
		while ((line = br.readLine()) != null) {
			System.out.println(line);
		}
		
		// Maneja los errores de ejecuci�n que pueden surgir
	} catch (SecurityException e) {
		System.out.println("Ha surgido un error debido a la falta de permisos");
		e.printStackTrace();
	} catch (Exception e) {
		System.out.println("Ha surgido un error inesperado");
		e.printStackTrace();
	}
		
	}
	
	

}