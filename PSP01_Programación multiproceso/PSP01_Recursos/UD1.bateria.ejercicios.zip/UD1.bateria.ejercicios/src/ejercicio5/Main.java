package ejercicio5;


import java.io.File;
import java.io.RandomAccessFile;
import java.io.PrintStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.nio.channels.FileLock; 
import java.util.Random;

/**
 * Aplicaci�n que genera palabras con letras aleatorias.
 * Recibe como par�metros, el n�mero de palabras a generar y el fichero en el
 * que las tiene que guardar.
 * La aplicaci�n tiene en cuenta que el fichero puede ser un recurso compartido
 * con otros procesos.
 */
public class Main {
    /**
    * Propiedad con el juego de letras que vamos a utilizar.
    */
    private static String abcdario = "abcdefghijklmnopqrstuvwxyz";
    /**
     * M�todo main de la aplicaci�n.
     * Recibe como par�metros, el n�mero de palabras a generar y el fichero en el
     * que las tiene que guardar.
     * La aplicaci�n tiene en cuenta que el fichero puede ser un recurso compartido
     * con otros procesos.
     * @param args Argumentos de la l�nea de comandos.
     * Primer argumento: num - n�mero de palabras a generar.
     * Segundo argumento: fichero - ruta y/o nombre del fichero en el que
     * se escribir�n las palabras.
     */
    public static void main(String[] args) {
      int numero = 0;
      String nombreFichero = "";
      File archivo = null;
      RandomAccessFile raf = null;
      FileLock bloqueo = null;
      String palabra = "";
      //Comprobamos si estamos recibiendo argumentos en la l�nea de comandos
      if (args.length < 2){
          errorSintaxis();
      }else{
        try{
            numero = Integer.parseInt(args[0]);
            //N�mero de palabras a generar
          }catch(Exception ex){
              errorSintaxis();
          }

        try{
            //Rediregimos salida y error est�ndar a un fichero
            PrintStream ps = new PrintStream(
                             new BufferedOutputStream(new FileOutputStream(
                             new File("javalog.txt"),true)), true);
            System.setOut(ps);
            System.setErr(ps);
        }catch(Exception e){
            System.err.println("No he podido redirigir salidas.");
        }

      //Identificamos el sistema operativo para poder acceder por su ruta al
      //fichero de forma correcta.
      String osName = System.getProperty("os.name");
      if (osName.toUpperCase().contains("WIN")){ //Windows
          nombreFichero = args[1].replace("\\", "\\\\");
          //Hemos recibido la ruta del fichero en la l�nea de comandos
      }else{ //GNU/Linux
          nombreFichero = args[1];
          //Hemos recibido la ruta del fichero en la l�nea de comandos
      }
      //Preparamos el acceso al fichero
      archivo = new File(nombreFichero);     
      for (int i=1; i<=numero; i++){//todas las palabras a generar
          palabra = nuevaPalabra(numero);
         try{
            raf = new RandomAccessFile(archivo,"rwd"); //Abrimos el fichero
           
            System.out.println("Proceso"+ numero + ": ENTRA secci�n");
            raf.seek(raf.length()); //nos posicionamos al final de fichero para a�adir
            raf.writeChars(palabra+"\n"); //escribimos el valor
            System.out.println("Proceso"+ numero + ": SALE secci�n");
          
            System.out.println("Proceso"+ numero +
                 ": valor escrito " + palabra);
        }catch(Exception e){
            System.err.println("P"+numero+" Error al acceder al fichero");
            System.err.println(e.toString());
        }finally{
            try{
                if( null != raf ) raf.close();
                if( null != bloqueo) bloqueo.release();
            }catch (Exception e2){
                System.err.println("P"+numero+" Error al cerrar el fichero");
                System.err.println(e2.toString());
                System.exit(1);  //Si hay error, finalizamos
            }
        }
       }

    }

}
 private static String nuevaPalabra(int numeroLetras){
    Random aleatorio = new Random();
    String aux = "";
    for (int i = 0; i<numeroLetras; i++){
        aux = aux + abcdario.charAt(aleatorio.nextInt(abcdario.length()));
    }

    return aux;
 }
 private static void errorSintaxis(){
          System.out.println("lenguaje - sintaxis:");
          System.out.println("     lenguaje numero fichero");
          System.exit(0);
    }
 
}
