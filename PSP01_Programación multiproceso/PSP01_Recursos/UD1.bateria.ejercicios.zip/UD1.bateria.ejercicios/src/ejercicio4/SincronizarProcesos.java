package ejercicio4;
import java.lang.Process;
import java.lang.Runtime;

public class SincronizarProcesos {
	

		public static void main(String[] args) {
			
			// Declaramos dos objetos de la clase Process
			
			Process p1;
			Process p2;
					
			try {
			
				// Lanzamos dos procesos y los asignamos a sus respectivos variables
				
				p1 = Runtime.getRuntime().exec("NOTEPAD");
				p2 = Runtime.getRuntime().exec("MSPAINT");
				
				// Informamos al programa que tiene que esparar a que finalice sus subprocesos para luego �l terminar
				
				int result1 = p1.waitFor();
				int result2 = p2.waitFor();			
				
				// Imprimimos a consola el c�digo de salida y un mensaje de confirmaci�n de que hayan finalizado
				
				System.out.println("Proceso 1 c�digo de salida: " + result1 + " || Proceso 2 c�digo de salida " + result2);
				System.out.println("Todos los procesos han finlizado");
				
				// Recogemos los errores que pueden surgir en tiempo de ejecuci�n
				
			} catch (InterruptedException e) {
				System.out.println("Hilo principal interrumpido");
				
			} catch (Exception e) {
				System.out.println("Un error inesperado ha surgido");
			}		
			
		}

	}

