package ejercicio2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.Process;
import java.lang.Runtime;

public class Generar {
	
	public static void main(String[] args) {
				
		try {
			// Este es el comando que ser� lanzado por el Runtime
			String comando =  "java -jar aleatorios.jar";
			
			// Un bucle for para lanzar 10 procesos y crear sus respectivos ficheros
			for (int i = 0; i < 10; i++) {
				
				// Lanzamos el .jar y asignamos el proceso a una variable
				Runtime run = Runtime.getRuntime();
				Process proceso = run.exec(comando);
				
				// Obtenemos el flujo de datos del proceso
				InputStream is = proceso.getInputStream();
				BufferedReader br = new BufferedReader(new InputStreamReader(is));
				
				// Creamos un fichero donde guardar los resutlados
				File fichero = new File("proceso_" + i + ".txt");
				
				// Esta es la linea que ser� leida del flujo
				String line;
				
				// Creamos un buffer para escribir al fichero
				BufferedWriter bw = new BufferedWriter(new FileWriter(fichero)); 
				
				// Mientras haya resultados en el flujo se escribir� al fichero correspondiente al proceso
				while ((line = br.readLine()) != null) 	{
					
					bw.write(line + "\n");
					
				}
				
				// Cerramso los flujos de lectura y escritura
				br.close();
				bw.close();
				
				// Comprobamos el valor de la salida del procesos, 0 es exitoso y 1 no.
				int exitValue;
				try {
					exitValue=proceso.waitFor();  // El proceso espara a que su subproceso finalice
					System.out.println("Valor de salida: " + exitValue);
				} catch (InterruptedException e) {
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				// Ver la ruta done ha guardado el fichero
				System.out.println(fichero.getAbsoluteFile());
			}
			
			// Capturar los errores que pueden ocurrir
			
		} catch (SecurityException e) {
			System.out.println("El proceso no se ha creado por falta de permisos.");
		} catch (IOException e) {
			System.out.println("Ha ocurrido un error de entrada/salida.");
			System.out.println(e.getStackTrace());
		} catch (Exception e) {
			System.out.println("Ha ocurrido un error inesperado.");
			System.out.println(e.getStackTrace());
		}
		
	}
}