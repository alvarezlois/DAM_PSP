package ejercicio1;

import java.util.Random;

public class Aleatorios {

	public static void main(String[] args) {
		
		// Intanciamos un Objeto de la clase Random
		Random r = new Random();
		
		// Creamos un bucle indicando las veces que queremos utlizar el m�todo de Random e imprimir el resutlado por pantalla
		for (int i = 0; i < 51; i++) {
						
			// Establecemos el numero tope, el resultado ser� entre 0 y este n�mero
			int max = 100;
			
			// Utilizamos el m�tido nextInt de la clase Random para generar un Integer entre el rango
			int resultado = r.nextInt(max);
			
			// Imprimimos el resultado de cada bucle a la consola
			System.out.println(resultado);
		}
	}	
}
