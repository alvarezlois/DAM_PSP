package ejercicio6;

/**
 * Aplicaci�n que lanza m�ltiples instancias de la aplicaci�n java.
 * Esas aplicaciones reciben como par�metro el n�mero de elementos a generar
 * y el nombre del fichero en el que los van a guardar.
 * @author Marga Nieto
 */
public class Main {

    /**
     * M�todo main() de la aplicaci�n. Punto de entrada de la aplicaci�n.
     * El archivo .jar de la aplicaci�n a instanciar, estar� en el mismo directorio
     * de esta aplicaci�n.
     * @param args argumentos en la l�nea de comandos. Ser�n ignorados.
     */
    public static void main(String[] args) {
       Process nuevoProceso; //Definimos una variable de tipo Process
        
       try{//lanzar la ejecuci�n de un proceso puede generar excepciones
            for (int i = 1; i <=10; i++){ //Crearemos 10 procesos
                nuevoProceso = Runtime.getRuntime().exec("java -jar "+
                    "lenguaje.jar " + i*10 + " ficheroResultado.txt");
                //Lanzamos la ejecuci�n de los procesos con los par�metros
                //indicados en el enunciado
            }
             System.out.println("Creados todos los procesos.");
        }catch (SecurityException ex){
            System.err.println("Ha ocurrido un error de Seguridad."+
                    "No se ha podido crear el proceso por falta de permisos.");
        }catch (Exception ex){
            System.err.println("Ha ocurrido un error, descripci�n: "+
                    ex.toString());
        }
    }

}
